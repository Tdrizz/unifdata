-- FrontierOps demo data
-- This seeds the most recently created company in the database.
-- Best used for a demo workspace.

with target_company as (
  select id
  from public.companies
  order by created_at desc
  limit 1
),

updated_company as (
  update public.companies
  set
    name = 'Pacific Green Landscaping',
    industry = 'Landscaping and property maintenance',
    business_sector = 'field_service'
  where id = (select id from target_company)
  returning id
),

inserted_customers as (
  insert into public.customers (
    company_id,
    name,
    phone,
    email,
    address,
    customer_type,
    notes
  )
  values
    ((select id from updated_company), 'Kona Coast Rentals', '808-555-0142', 'manager@konacoastrentals.com', '75-5801 Alii Dr, Kailua-Kona, HI', 'Commercial', 'Vacation rental property. Wants recurring lawn and cleanup service.'),
    ((select id from updated_company), 'Sarah Miller', '808-555-0188', 'sarah@example.com', 'Holualoa, HI', 'Residential', 'Asked about monthly mowing and hedge trimming.'),
    ((select id from updated_company), 'Ocean View Market', '808-555-0199', 'owner@oceanviewmarket.com', 'Ocean View, HI', 'Commercial', 'Needs cleanup before busy weekend traffic.'),
    ((select id from updated_company), 'Mike Johnson', '808-555-0110', null, 'Captain Cook, HI', 'Residential', 'Requested irrigation repair estimate.'),
    ((select id from updated_company), 'Aloha Property Group', null, 'ops@alohapropertygroup.com', null, 'Commercial', 'Multiple properties. Missing direct phone and address.'),
    ((select id from updated_company), 'Grace Apartments', '808-555-0133', 'maintenance@graceapts.com', 'Kailua-Kona, HI', 'Commercial', 'Potential recurring contract. Wants weekly maintenance.')
  returning id, name
),

inserted_leads as (
  insert into public.leads (
    company_id,
    customer_id,
    service_requested,
    status,
    estimated_value,
    source,
    next_follow_up_date,
    notes
  )
  values
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Kona Coast Rentals'),
      'Recurring lawn maintenance',
      'Estimate Sent',
      4200,
      'Referral',
      current_date,
      'High-value commercial recurring service. Follow up today.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Sarah Miller'),
      'Monthly mowing and hedge trimming',
      'Contacted',
      650,
      'Google',
      current_date + interval '2 days',
      'Interested but wants to compare pricing.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Ocean View Market'),
      'Lot cleanup and green waste removal',
      'Needs Follow-Up',
      1200,
      'Facebook',
      current_date - interval '1 day',
      'Asked for rush cleanup. Needs callback.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Mike Johnson'),
      'Irrigation repair',
      'Estimate Sent',
      900,
      'Google',
      current_date - interval '3 days',
      'Estimate sent but no reply yet.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Grace Apartments'),
      'Weekly apartment landscaping contract',
      'New',
      5600,
      'Referral',
      current_date + interval '4 days',
      'Potential contract for weekly exterior maintenance.'
    )
  returning id, service_requested
),

inserted_jobs as (
  insert into public.jobs (
    company_id,
    customer_id,
    lead_id,
    service_type,
    status,
    job_value,
    start_date,
    completed_date,
    paid_status,
    notes
  )
  values
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Sarah Miller'),
      (select id from inserted_leads where service_requested = 'Monthly mowing and hedge trimming'),
      'Mowing and hedge trimming',
      'Scheduled',
      650,
      current_date + interval '1 day',
      null,
      'Unpaid',
      'First monthly service. Confirm gate access before arrival.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Ocean View Market'),
      (select id from inserted_leads where service_requested = 'Lot cleanup and green waste removal'),
      'Green waste removal',
      'In Progress',
      1200,
      current_date,
      null,
      'Partial',
      'Rush cleanup. Half paid upfront.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Kona Coast Rentals'),
      (select id from inserted_leads where service_requested = 'Recurring lawn maintenance'),
      'Recurring lawn maintenance',
      'Scheduled',
      4200,
      current_date + interval '3 days',
      null,
      'Unpaid',
      'Potential recurring contract if first job goes well.'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Mike Johnson'),
      (select id from inserted_leads where service_requested = 'Irrigation repair'),
      'Irrigation repair',
      'Completed',
      900,
      current_date - interval '7 days',
      current_date - interval '6 days',
      'Paid',
      'Completed repair and replaced broken sprinkler heads.'
    )
  returning id, service_type
),

inserted_sales as (
  insert into public.sales (
    company_id,
    customer_id,
    job_id,
    amount,
    payment_status,
    sale_date,
    service_type,
    source
  )
  values
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Mike Johnson'),
      (select id from inserted_jobs where service_type = 'Irrigation repair'),
      900,
      'Paid',
      current_date - interval '6 days',
      'Irrigation repair',
      'Google'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Ocean View Market'),
      (select id from inserted_jobs where service_type = 'Green waste removal'),
      1200,
      'Partial',
      current_date,
      'Green waste removal',
      'Facebook'
    ),
    (
      (select id from updated_company),
      (select id from inserted_customers where name = 'Sarah Miller'),
      (select id from inserted_jobs where service_type = 'Mowing and hedge trimming'),
      650,
      'Unpaid',
      current_date,
      'Mowing and hedge trimming',
      'Google'
    )
  returning id
)

insert into public.follow_ups (
  company_id,
  customer_id,
  lead_id,
  due_date,
  status,
  message
)
values
  (
    (select id from updated_company),
    (select id from inserted_customers where name = 'Kona Coast Rentals'),
    (select id from inserted_leads where service_requested = 'Recurring lawn maintenance'),
    current_date,
    'Open',
    'Call Kona Coast Rentals about the recurring maintenance estimate.'
  ),
  (
    (select id from updated_company),
    (select id from inserted_customers where name = 'Ocean View Market'),
    (select id from inserted_leads where service_requested = 'Lot cleanup and green waste removal'),
    current_date - interval '1 day',
    'Open',
    'Follow up on remaining payment after rush cleanup.'
  ),
  (
    (select id from updated_company),
    (select id from inserted_customers where name = 'Mike Johnson'),
    (select id from inserted_leads where service_requested = 'Irrigation repair'),
    current_date + interval '7 days',
    'Open',
    'Check if irrigation repair is still working properly.'
  ),
  (
    (select id from updated_company),
    (select id from inserted_customers where name = 'Grace Apartments'),
    (select id from inserted_leads where service_requested = 'Weekly apartment landscaping contract'),
    current_date + interval '2 days',
    'Open',
    'Send follow-up message about weekly landscaping contract.'
  );

insert into public.ai_reports (
  company_id,
  report_type,
  summary
)
values (
  (select id from updated_company),
  'business_summary',
  'Today’s priority is follow-up and collections. Pacific Green Landscaping has open quote value sitting with Kona Coast Rentals and Grace Apartments, plus unpaid or partial revenue from current service work. The best next steps are to follow up with Kona Coast Rentals, collect the remaining Ocean View Market balance, and clean up customer records missing contact or address details.'
);